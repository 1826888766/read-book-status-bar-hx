var biquge = require("./biquge.js");
var qidian = require("./qidian.js");
var zongheng = require("./zongheng.js");

module.exports = {
	biquge,
	qidian,
	zongheng
}